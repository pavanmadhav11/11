from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pyflowchart import Flowchart
import ast

app = FastAPI()

class CodeInput(BaseModel):
    code: str

@app.post("/generate-flowchart/")
async def generate_flowchart(data: CodeInput):
    try:
        code_ast = ast.parse(data.code)
        flowchart = Flowchart.from_code(data.code)
        return {"flowchart": flowchart.flowchart()}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/")
async def root():
    return {"message": "Python to Flowchart API is running"}

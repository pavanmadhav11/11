#!/bin/bash
cd backend
uvicorn main:app --reload

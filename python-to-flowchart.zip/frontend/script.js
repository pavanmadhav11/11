async function generateFlowchart() {
    const code = document.getElementById("codeInput").value;

    const response = await fetch("http://127.0.0.1:8000/generate-flowchart/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code })
    });

    const data = await response.json();
    if (response.ok) {
        const flowchartData = data.flowchart;
        const chart = flowchart.parse(flowchartData);
        document.getElementById("canvas").innerHTML = "";
        chart.drawSVG("canvas");
    } else {
        alert("Error: " + data.detail);
    }
}
